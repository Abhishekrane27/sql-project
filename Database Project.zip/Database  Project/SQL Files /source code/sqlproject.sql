/*--Database creation*/
create database UMS
use UMS
go
/*Table creation*/
--1. Table Department*/
create table department(dep_id int Primary Key, dep_name varchar(20) UNIQUE, HOD varchar(20) NOT NULL,
 total_students int NOT NULL, total_faculty int NOT NULL, sub_dep int DEFAULT NULL )
 select * from department
--2. Table Degree*/
create table degree(deg_id int Primary Key, deg_name varchar(20) UNIQUE, total_subjects int NOT NULL,
 total_credit_hours int NOT NULL, duration nvarchar(30) NOT NULL,total_semesters int NOT NULL, 
 total_fee int NOT NULL, dep_id int references department(dep_id))
 select * from degree
--3. Table semester
create table semester(semester_id int Primary Key, total_subjects int NOT NULL, 
degree_id int references degree(deg_id),semester_no int NOT NULL)
select * from semester
--4. Table section
create table section(sec_id int Primary Key, sec_title varchar(10) NOT NULL,
timing varchar(20) NOT NULL, degree_id int references degree(deg_id), 
semester_id int references semester(semester_id))
select * from section
--5. Table student
create table students( std_id int Primary Key, fname varchar(20) NOT NULL,lname varchar(20) NOT NULL,
fathername varchar(20) NOT NULL,rollno int UNIQUE, mobile_no int UNIQUE, address nvarchar(50) NOT NULL,
age int NOT NULL CHECK (age >= 16),email nvarchar(30) UNIQUE,degree_id int references degree(deg_id),
semester_id int references semester(semester_id), section_id int references section(sec_id))
select * from students
--6. Table subjects
create table subjects(sub_id int Primary Key, name varchar(20) NOT NULL UNIQUE, 
degree_id int references degree(deg_id),semester_id int references semester(semester_id), 
section_id int references section(sec_id), department_id int references department(dep_id))
select * from subjects
--7. Table faculty
create table faculty (fac_id int Primary Key, fac_name varchar(20) NOT NULL, phone_no int UNIQUE NOT NULL, 
email nvarchar(20) UNIQUE NOT NULL, address nvarchar(30) NOT NULL, age int NOT NULL CHECK (age >= 20),
department_id int references department(dep_id),subject_id int references subjects(sub_id),
semester_id int references semester(semester_id), section_id int references section(sec_id))
select * from faculty
--8. Table Attendance
create table attendance(att_id int Primary Key, student_id int references students(std_id),
subject_id int references subjects(sub_id),status char NOT NULL, date date NOT NULL,
teacher_id int references faculty(fac_id),semester_id int references semester(semester_id), 
section_id int references section(sec_id), department_id int references department(dep_id))
select * from attendance
--9. Table Examinations
create table examinations (ex_id int Primary Key, type varchar(20) NOT NULL, date date NOT NULL, 
subject_id int references subjects(sub_id), degree_id int references degree(deg_id),
semester_id int references semester(semester_id), section_id int references section(sec_id),
department_id int references department(dep_id))
select * from examinations
--10. Table Accounts
create table accounts (acc_id int Primary Key, voucher_no int NOT NULL, due_date date NOT NULL, 
status varchar(20) NOT NULL, student_id int references students(std_id),degree_id int references degree(deg_id),
semester_id int references semester(semester_id), section_id int references section(sec_id),
department_id int references department(dep_id))
select * from accounts
--11. Table Computer Labs
create table computerlabs(lab_id int Primary Key, lab_name varchar(20) NOT NULL,
 lab_attendant varchar(20) UNIQUE NOT NULL, total_pc int NOT NULL, timings varchar(20) NOT NULL)
select * from computerlabs
--12. Table Library
create table library(lib_id int Primary Key, admin varchar(20) NOT NULL, lab_attendant varchar(20) UNIQUE)
select * from library
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
-- Inserting Values in Department
insert into department values (1,'CS','Ahmad Butt', 500,30,NULL)
insert into department values (2,'IT','Shamaz Malik', 400,30,NULL)
insert into department values (3,'SE','Basit Ali', 350,25,NULL)
insert into department values (4,'Aviation','Ali Abbas', 400,29,NULL)
insert into department values (5,'Medical','Ahmad Kaloon', 600,35,3)
insert into department values (6,'EE','Zargham Abbas', 300,30,NULL)
insert into department values (7,'English Language','Tahir Hassan', 250,15,NULL)
insert into department values (8,' BA','Anees Haider', 200,19,NULL)
insert into department values (9,'Management Sciences','Amil Hayat', 350,24,NULL)
insert into department values (10,'Economics','Atif Ali', 400,25,NULL)
 select * from department
-- Inserting Values in Degree
insert into degree values (1, 'BSCS', 42, 135,'4 years',8,924000,1)
insert into degree values (2, 'BSIT', 42, 135,'4 years',8,924000,2)
insert into degree values (3, 'BSSE', 42, 135,'4 years',8,924000,3)
insert into degree values (4, 'BSAM', 40, 126,'4 years',8,848000,4)
insert into degree values (5, 'MSC', 25, 72,'2 years',4,235000,10)
insert into degree values (6, 'PHD', 48, 48,'3 years',0,381000,6)
insert into degree values (7, 'MS/MPHIL', 8, 30,'2 years',4,252000,8)
insert into degree values (8, 'MBA', 30, 96,'3.5 years',6,641000,8)
insert into degree values (9, 'Doctor of Pharmacy', 63, 197,'5 years',10,1090000,5)
insert into degree values (10, 'MBBS', 30, 96,'3.5 years',6,641000,5)
 select * from degree
 -- Inserting Values in Semester
insert into semester values (1,6,1,1)
insert into semester values (2,5,1,2)
insert into semester values (3,5,1,3)
insert into semester values (4,6,1,4)
insert into semester values (5,6,2,1)
insert into semester values (6,5,2,2)
insert into semester values (7,5,2,3)
insert into semester values (8,6,2,4)
insert into semester values (9,6,3,1)
insert into semester values (10,6,3,4)
 select * from semester
 -- Inserting Values in Section
 insert into section values (1,'1A','Morning',1,1)
insert into section values (2,'2A','Morning',1,2)
insert into section values (3,'3A','Morning',1,3)
insert into section values (4,'4A','Morning',1,4)
insert into section values (5,'2B','Morning',2,5)
insert into section values (6,'2B','Morning',2,6)
insert into section values (7,'4C','Evening',2,8)
insert into section values (8,'3C','Evening',2,7)
insert into section values (9,'4D','Evening',3,10)
insert into section values (10,'4B','Morning',1,4)
 select * from section
 -- Inserting Values in students
insert into students values (1,'Arman','Ali','Imran',070,033497312,'Tag Society Houseno4',20,'arman@gmail.com',1,4,10)
insert into students values (2,'Tajdar','Hussain','Hussain',117,033495412,'Thokar Houseno4',20,'tajdar@gmail.com',1,4,10)
insert into students values (3,'Samreen','Zafar','Zafar',077,033492312,'Hostel roomno4',21,'samreen@gmail.com',1,4,10)
insert into students values (4,'Ali','Sheraz','Ali',107,033497319,'Multan Road Houseno4',22,'sherazi@gmail.com',1,4,10)
insert into students values (5,'Hamza','Ejaz','Ejaz',102,033443312,'Ali Society Houseno4',20,'ejaz@gmail.com',1,4,10)
insert into students values (6,'Asad','Dogar','Ali',089,033497315,'Quiad Society',20,'dogar@gmail.com',1,4,10)
insert into students values (7,'Usman','Afzal','Afzal',063,033497310,'Thokar Niaz Houseno4',20,'usman@gmail.com',1,4,10)
insert into students values (8,'Khizar','Khan','Shoaib',080,033497376,'Hassan Socity Houseno9',25,'khizar@gmail.com',1,4,10)
insert into students values (9,'Farhan','Qadeer','Qadeer',099,033497882,'Tag Society Houseno5',23,'farhan@gmail.com',1,4,10)
insert into students values (10,'Yasir','Akram','Ali',112,03349765,'Tag Society Houseno1',26,'yassir@gmail.com',1,4,10)
select * from students
-- Inserting Values in subjects
insert into subjects values(1,'PF',1,1,1,1)
insert into subjects values(2,'Calculus',1,1,1,1)
insert into subjects values(3,'I2C',1,1,1,1)
insert into subjects values(4,'Basic Electronics',1,1,1,1)
insert into subjects values(5,'Islamiyat',1,1,1,1)
insert into subjects values(6,'English',1,1,1,1)
insert into subjects values(7,'OOP',1,3,3,1)
insert into subjects values(8,'DE',1,3,3,1)
insert into subjects values(9,'Database',1,4,10,1)
insert into subjects values(10,'Web',1,4,10,1)
select * from subjects
-- Inserting Values in faculty
insert into faculty values (1,'Sir Farrukh',23239424,'farrukh@gmail.com','123 house no3',25,1,1,1,1)
insert into faculty values (2,'Sir Manan',232394231,'manan@gmail.com','123 house no2',25,1,2,1,1)
insert into faculty values (3,'Mam Rabia',32239424,'rabia@gmail.com','123 house no4',25,1,3,1,1)
insert into faculty values (4,'Sir Junaid',24539424,'junaid@gmail.com','123 house no5',30,1,4,1,1)
insert into faculty values (5,'Sir Ahmad',23239354,'ahmad@gmail.com','123 house no6',32,1,5,1,1)
insert into faculty values (6,'Mam Anila',23224424,'anila@gmail.com','123 house no7',32,1,6,1,1)
insert into faculty values (7,'Dr Amna',23239423,'amna@gmail.com','123 house no8',35,1,7,3,3)
insert into faculty values (8,'Sir Asad',23339424,'asad@gmail.com','123 house no9',40,1,8,3,3)
insert into faculty values (9,'Sir Faheem',23129424,'faheem@gmail.com','123 house no1',30,1,9,4,10)
insert into faculty values (10,'Sir Umar',23247424,'umarr@gmail.com','123 house no10',25,1,10,4,10)
select * from faculty
-- Inserting Values in Attendance
insert into attendance values(1,1,9,'P','1-04-19',9,4,10,1)
insert into attendance values(2,1,9,'P','2-04-19',9,4,10,1)
insert into attendance values(3,1,9,'A','3-04-19',9,4,10,1)
insert into attendance values(4,1,9,'P','4-04-19',9,4,10,1)
insert into attendance values(5,1,9,'A','5-04-19',9,4,10,1)
insert into attendance values(6,1,9,'P','8-04-19',9,4,10,1)
insert into attendance values(7,1,9,'P','9-04-19',9,4,10,1)
insert into attendance values(8,1,9,'A','10-04-19',9,4,10,1)
insert into attendance values(9,1,9,'P','11-04-19',9,4,10,1)
insert into attendance values(10,1,9,'P','12-04-19',9,4,10,1)
select * from attendance
-- Inserting Values in Examinations
insert into examinations values (1,'Mid','1-05-19',1,1,1,1,1)
insert into examinations values (2,'Mid','2-05-19',2,1,1,1,1)
insert into examinations values (3,'Mid','3-05-19',3,1,1,1,1)
insert into examinations values (4,'Mid','4-05-19',4,1,1,1,1)
insert into examinations values (5,'Mid','5-05-19',5,1,1,1,1)
insert into examinations values (6,'Mid','6-05-19',6,1,1,1,1)
insert into examinations values (7,'Mid','8-05-19',7,1,3,3,1)
insert into examinations values (8,'Mid','1-05-19',8,1,3,3,1)
insert into examinations values (9,'Mid','2-05-19',9,1,4,10,1)
insert into examinations values (10,'Mid','3-05-19',10,4,10,1,1)
select * from examinations
-- Inserting Values in Accounts
insert into accounts values (1,1,'190511','NOT SUBMITTED',2,1,4,10,1)
insert into accounts values (2,2,'190511','NOT SUBMITTED',4,1,4,10,1)
insert into accounts values (3,1,'190519','SUBMITTED',3,1,4,10,1)
insert into accounts values (4,2,'190521','NOT SUBMITTED',1,1,4,10,1)
insert into accounts values (5,1,'190521','SUBMITTED',8,1,4,10,1)
insert into accounts values (6,4,'190519','NOT SUBMITTED',5,1,4,10,1)
insert into accounts values (7,1,'190519','NOT SUBMITTED',7,1,4,10,1)
insert into accounts values (8,2,'190525','SUBMITTED',6,1,4,10,1)
insert into accounts values (9,3,'190525','SUBMITTED',3,1,4,10,1)
insert into accounts values (10,1,'100520','SUBMITTED',1,1,4,10,1)
select * from accounts
-- Inserting Values in ComputerLabs
insert into computerlabs values (1,'Lab-1','Sir Assad',25,'Morning')
insert into computerlabs values (2,'Lab-2','Sir Hassan',25,'Evening')
insert into computerlabs values (3,'Lab-3','Sir Umer',25,'Morning')
insert into computerlabs values (4,'Lab-4','Sir Kashif',25,'Evening')
insert into computerlabs values (5,'Lab-5','Sir Kahloon',25,'Morning')
insert into computerlabs values (6,'Lab-6','Sir Nadeem',25,'Evening')
insert into computerlabs values (7,'Lab-7','Sir Umair',25,'Morning')
insert into computerlabs values (8,'Lab-8','Sir Noman',25,'Evening')
insert into computerlabs values (9,'Lab-9','Mam Ayesha',25,'Morning')
insert into computerlabs values (10,'Lab-10','Sir Zaman',25,'Evening')
select * from computerlabs
-- Inserting Values in Library
insert into library values (1,'Sir Adil','Sir Amil')
insert into library values (2,'Sir Qatar','Sir Tahir')
insert into library values (3,'Sir Hussain','Sir Anil')
insert into library values (4,'Sir Adil','Mam Sabah')
insert into library values (5,'Sir Kamran','Sir Hassan')
insert into library values (6,'Sir Ahmar','Sir Arman')
insert into library values (7,'Sir Farooq','Sir Tajdar')
insert into library values (8,'Sir Adil','Mam Ayesha')
insert into library values (9,'Sir Farooq','Mam Samreen')
insert into library values (10,'Sir Adil','Sir Ali')
select * from library
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- 1 Select
select fname, lname, fathername, section_id from students
-- 2 Select *
select * from faculty
-- Where Clause
select * from degree where dep_id=1
-- Like Clause 1
select * from students where fname LIKE '%a%'
--Like Clause 2
select * from students where fname LIKE '_l_'
--Like Clause 3
select * from faculty where fac_name LIKE '_a%'
--Arithmetic Operator +
select total_credit_hours,total_credit_hours+2000 as addexample from degree
--Arithmetic Operator *
select total_credit_hours,total_credit_hours*2 as multiplyexample from degree
--Arithmetic Operator -
select total_fee,total_fee-20000 as subtractexample from degree where dep_id=1
-- Arithmetic Operator /
select total_fee,total_fee/2 as divideexample from degree where deg_id=7
--Conjuctive Operator AND
select * from department where total_students >500 AND sub_dep=3
--Conjuctive Operator OR
select * from section where degree_id=2 OR timing='Evening'
--Conjuctive Operator AND & OR
select fname, lname, degree_id from students where age>=22 AND semester_id=4 OR section_id=8
--Comparison Operator
select * from accounts where status = 'NOT SUBMITTED'
--Delete
Delete from accounts where student_id = 5
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- Inner Join 
select fname as studentname, fac_name as teachername from students INNER JOIN faculty on students.section_id=faculty.section_id
-- Left Join
select fname as studentname, date, status from students
LEFT JOIN attendance on students.std_id=attendance.student_id order by fname ASC
-- Right Join
select fname as studentname, due_date,status from students
RIGHT JOIN accounts on students.std_id=accounts.student_id order by fname DESC
-- Full Join
select fname as studentname, type as paper, date from students
FULL JOIN examinations on students.semester_id=examinations.semester_id
-- Cross Join
select std_id, fname, students.semester_id, semester_no,semester.semester_id from students, semester
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- Store Procedure Simple
create Procedure studentinsert
@id int,@firstname varchar(20),@lastname varchar(20),@fathername varchar(20),@phno int,
@rollno int,@address nvarchar(30),@age int,@email nvarchar(40),@degree int,@semester int,@section int
as
Begin
insert into students values(@id,@firstname,@lastname,@fathername,@phno,@rollno,@address, @age,@email,@degree,@semester,@section)
End
EXEC studentinsert 11,'Taha','Ali','Butt',1234532,192,'123 street 2',23,'taha@gmail.com',1,4,4
-- Store Procedure Output Parameter
create Procedure countstudentID
@age int,@id int output 
as
Begin
select @id=Count(std_id) from students where age>@age
End
Declare @countid int
EXEC countstudentID 20,@countid output 
Print @countid
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- View 1
create view studentview
as
select std_id, fname,lname, fathername, rollno,mobile_no,address,age,email,deg_name from students
Inner Join degree on students.degree_id=degree.deg_id

select * from studentview

-- View 2
create view studentvoucher
as
select voucher_no, due_date, status, fname as studentname from accounts
Inner Join students on accounts.student_id=students.std_id

select * from studentvoucher

-- View 3
create view teacherview
as
select fac_name, phone_no,email,address,age,name as subject_name from faculty
Inner Join subjects on faculty.subject_id=subjects.sub_id

select * from teacherview
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- Aggregate Functions
--Average Funtion
select AVG(total_fee) from degree
--Count Funtion
select COUNT(std_id) from students
--Sum Funtion
select SUM(total_credit_hours) from degree
--Minimum Funtion
select MIN(total_fee) from degree
--Maximum Funtion
select MAX(total_fee) from degree

-- Scalar Functions
--Lower Funtion
select LOWER(fname) from students
--Upper Funtion
select UPPER(fname) from students
--Concat Funtion
select CONCAT(fname,lname) from students
--Substring Funtion
select SUBSTRING(fname,1,2) from students
--Round Funtion
select ROUND(total_credit_hours,1,2) from degree


-------------------------------THE END---------------------------------

